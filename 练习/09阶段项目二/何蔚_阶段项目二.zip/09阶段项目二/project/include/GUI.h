#ifndef __GUI_H
#define __GUI_H
#include "main.h"

void Login(void);

void Function_Selection_1(char * name);

void Function_Selection_2(void);


#endif